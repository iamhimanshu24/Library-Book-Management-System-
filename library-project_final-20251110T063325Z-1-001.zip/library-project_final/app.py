
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.String(50), unique=True, nullable=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(200), nullable=False)
    available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    borrower = db.Column(db.String(200))
    action = db.Column(db.String(20))  # 'issue' or 'return'
    action_date = db.Column(db.DateTime, default=datetime.utcnow)



with app.app_context():
    db.create_all()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/books', methods=['GET'])
def list_books():
    q = request.args.get('q', '').strip()
    available = request.args.get('available')
    query = Book.query
    if q:
        query = query.filter((Book.title.ilike(f'%{q}%')) | (Book.author.ilike(f'%{q}%')) | (Book.book_id.ilike(f'%{q}%')))
    if available is not None:
        if available.lower() in ('true','1'):
            query = query.filter_by(available=True)
        else:
            query = query.filter_by(available=False)
    books = query.order_by(Book.id.desc()).all()
    return jsonify([{
        'id': b.id,
        'book_id': b.book_id,
        'title': b.title,
        'author': b.author,
        'available': b.available
    } for b in books])


@app.route('/api/books', methods=['POST'])
def add_book():
    data = request.json or {}
    title = data.get('title')
    author = data.get('author')
    book_id = data.get('book_id') or None
    if not title or not author:
        return jsonify({'error': 'title and author required'}), 400
    b = Book(title=title, author=author, book_id=book_id)
    db.session.add(b)
    db.session.commit()
    return jsonify({'message': 'book added', 'id': b.id}), 201


@app.route('/api/books/<int:id>/issue', methods=['POST'])
def issue_book(id):
    data = request.json or {}
    borrower = data.get('borrower')
    if not borrower:
        return jsonify({'error': 'borrower required'}), 400
    b = Book.query.get_or_404(id)
    if not b.available:
        return jsonify({'error': 'book already issued'}), 400
    b.available = False
    tx = Transaction(book_id=b.id, borrower=borrower, action='issue')
    db.session.add(tx)
    db.session.commit()
    return jsonify({'message': 'book issued'})


@app.route('/api/books/<int:id>/return', methods=['POST'])
def return_book(id):
    data = request.json or {}
    b = Book.query.get_or_404(id)
    if b.available:
        return jsonify({'error': 'book is already available'}), 400
    b.available = True
    tx = Transaction(book_id=b.id, borrower=data.get('borrower',''), action='return')
    db.session.add(tx)
    db.session.commit()
    return jsonify({'message': 'book returned'})


@app.route('/api/transactions', methods=['GET'])
def list_transactions():
    txs = Transaction.query.order_by(Transaction.action_date.desc()).all()
    return jsonify([{
        'id': t.id, 'book_id': t.book_id, 'borrower': t.borrower,
        'action': t.action, 'action_date': t.action_date.isoformat()
    } for t in txs])

if __name__ == '__main__':
    app.run(debug=True)
