async function api(path, opts = {}) {
  const res = await fetch(path, Object.assign({ headers: {'Content-Type':'application/json'} }, opts));
  return res.json();
}

async function addBook() {
  const book_id = document.getElementById('book_id').value.trim();
  const title = document.getElementById('title').value.trim();
  const author = document.getElementById('author').value.trim();
  if (!title || !author) { alert('title & author required'); return; }
  await api('/api/books', { method: 'POST', body: JSON.stringify({ book_id, title, author }) });
  document.getElementById('book_id').value = '';
  document.getElementById('title').value = '';
  document.getElementById('author').value = '';
  loadBooks();
}

function makeBookDiv(b) {
  const div = document.createElement('div');
  div.className = 'book';
  const left = document.createElement('div');
  left.innerHTML = `<strong>${b.title}</strong> <div>Author: ${b.author} ${b.book_id ? ' | ID: '+b.book_id : ''}</div>`;
  const right = document.createElement('div');
  const badge = document.createElement('span');
  badge.className = 'badge ' + (b.available ? 'available' : 'issued');
  badge.textContent = b.available ? 'Available' : 'Issued';
  right.appendChild(badge);

  if (b.available) {
    const issueBtn = document.createElement('button');
    issueBtn.textContent = 'Issue';
    issueBtn.onclick = async () => {
      const borrower = prompt('Borrower name:');
      if (!borrower) return;
      await api(`/api/books/${b.id}/issue`, {method:'POST', body: JSON.stringify({ borrower })});
      loadBooks();
    };
    right.appendChild(issueBtn);
  } else {
    const returnBtn = document.createElement('button');
    returnBtn.textContent = 'Return';
    returnBtn.onclick = async () => {
      const borrower = prompt('Returner name (optional):','');
      await api(`/api/books/${b.id}/return`, {method:'POST', body: JSON.stringify({ borrower })});
      loadBooks();
    };
    right.appendChild(returnBtn);
  }

  div.appendChild(left);
  div.appendChild(right);
  return div;
}

async function loadBooks(q='') {
  const query = q ? `?q=${encodeURIComponent(q)}` : '';
  const data = await api('/api/books' + query);
  const container = document.getElementById('books');
  container.innerHTML = '';
  if (!data.length) container.textContent = 'No books found.';
  data.forEach(b => container.appendChild(makeBookDiv(b)));
}

document.getElementById('addBtn').addEventListener('click', addBook);
document.getElementById('searchBtn').addEventListener('click', () => loadBooks(document.getElementById('q').value.trim()));
document.getElementById('refreshBtn').addEventListener('click', () => { document.getElementById('q').value=''; loadBooks(); });

window.onload = () => loadBooks();
